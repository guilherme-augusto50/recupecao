﻿namespace recuperaçao
{
    partial class cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cadastro));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNome = new TextBox();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            btncadastre = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(189, 96);
            label1.Name = "label1";
            label1.Size = new Size(54, 18);
            label1.TabIndex = 0;
            label1.Text = "Nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(189, 233);
            label2.Name = "label2";
            label2.Size = new Size(57, 18);
            label2.TabIndex = 1;
            label2.Text = "Senha:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(189, 164);
            label3.Name = "label3";
            label3.Size = new Size(52, 18);
            label3.TabIndex = 2;
            label3.Text = "Email:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(189, 126);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(204, 26);
            txtNome.TabIndex = 1;
            txtNome.TextChanged += textBox1_TextChanged;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(189, 263);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(204, 26);
            txtSenha.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(189, 194);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(204, 26);
            txtEmail.TabIndex = 2;
            // 
            // btncadastre
            // 
            btncadastre.Location = new Point(212, 333);
            btncadastre.Name = "btncadastre";
            btncadastre.Size = new Size(151, 34);
            btncadastre.TabIndex = 4;
            btncadastre.Text = "Cadastre-se";
            btncadastre.UseVisualStyleBackColor = true;
            btncadastre.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(471, 12);
            button2.Name = "button2";
            button2.Size = new Size(102, 29);
            button2.TabIndex = 5;
            button2.Text = "Voltar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // cadastro
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(605, 494);
            Controls.Add(button2);
            Controls.Add(btncadastre);
            Controls.Add(txtEmail);
            Controls.Add(txtSenha);
            Controls.Add(txtNome);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "cadastro";
            StartPosition = FormStartPosition.CenterParent;
            Text = "cadastro";
            FormClosed += cadastro_FormClosed;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNome;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private Button btncadastre;
        private Button button2;
    }
}