﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cms;

namespace recuperaçao
{
    internal class tarefas
    {
        private int id;
        private string nome;
        private string descricao;
        private DateTime data;
        private DateTime hora;
        private int idUsuario;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }
        public DateTime Data
        {
            get { return data; }
            set { data = value; }
        }
        public DateTime Hora
        {
            get { return hora; }
            set { hora = value; }
        }
        public int IdUsuario
        {
            get { return idUsuario; }
            set { idUsuario = value; }
        }

        public void InserirTarefa()
        {
            try
            {
                DateTime dataMysql = Convert.ToDateTime(Data);
                
                string dataFormatada = dataMysql.ToString("yyyy-MM-dd");
                using (MySqlConnection conexao = new ConexaoDb().Conectar())
                {
                    string query = "INSERT INTO tarefas (nome, descriçao, data_entrega, horario, Id_usuario) VALUES (@nome, @descriçao, @data_entrega, @horario, @Id_usuario)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@nome", Nome);
                        cmd.Parameters.AddWithValue("@descriçao", Descricao);
                        cmd.Parameters.AddWithValue("@data_entrega", dataFormatada);
                        cmd.Parameters.AddWithValue("@horario", Hora);
                        cmd.Parameters.AddWithValue("@Id_usuario", IdUsuario);
                        int resultado = cmd.ExecuteNonQuery();
                        if (resultado > 0)
                        {
                            Console.WriteLine("Tarefa inserida com sucesso!");
                        }
                        else
                        {
                            Console.WriteLine("Erro ao inserir tarefa.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao inserir tarefa: " + ex.Message);
            }
        }
        public DataTable listar(int IdUsuario)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoDb().Conectar())
                {
                    string query = "SELECT * FROM tarefas WHERE Id_usuario = @Id_usuario";

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Id_usuario", IdUsuario); // Filtra pelo usuário logado

                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar tarefas: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }
        public void atualizar()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoDb().Conectar())
                {
                    string query = "UPDATE tarefas SET nome = @nome, data_entrega = @data_entrega, horario = @horario, descriçao = @descriçao WHERE Id_tarefas = @Id_tarefas AND Id_usuario = @Id_usuario";

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Id_tarefas", Id);
                        cmd.Parameters.AddWithValue("@nome", Nome);
                        cmd.Parameters.AddWithValue("@descriçao", Descricao);
                        cmd.Parameters.AddWithValue("@data_entrega", Data);
                        cmd.Parameters.AddWithValue("@horario", Hora);
                        cmd.Parameters.AddWithValue("@Id_usuario", IdUsuario);
                        int resultado = cmd.ExecuteNonQuery();
                        if (resultado > 0)
                        {
                            Console.WriteLine("Tarefa atualizada com sucesso!");
                        }
                        else
                        {
                            Console.WriteLine("Erro ao atualizar tarefa.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao atualizar tarefa: " + ex.Message);
            }
        }
        public void excluir()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoDb().Conectar())
                {
                    string query = "DELETE FROM tarefas WHERE Id_tarefas = @Id_tarefas AND Id_usuario = @Id_usuario";

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Id_tarefas", Id);
                        cmd.Parameters.AddWithValue("@Id_usuario", IdUsuario);
                        int resultado = cmd.ExecuteNonQuery();
                        if (resultado > 0)
                        {
                            Console.WriteLine("Tarefa excluída com sucesso!");
                        }
                        else
                        {
                            Console.WriteLine("Erro ao excluir tarefa.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao excluir tarefa: " + ex.Message);
            }
        }
        public DataTable listarpordata(int IdUsuario, DateTime Data) {
            try {
                using (MySqlConnection conexao = new ConexaoDb().Conectar()) {
                    string query = "SELECT * FROM tarefas WHERE Id_usuario = @Id_usuario AND data_entrega = @data_entrega ORDER By horario ASC";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Id_usuario", IdUsuario);
                        cmd.Parameters.AddWithValue("@data_entrega", Data.Date); // Filtra pela data específica

                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar tarefas por data: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

        }
    }
}
